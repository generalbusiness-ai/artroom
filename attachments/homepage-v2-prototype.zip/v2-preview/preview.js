// Keep the canonical homepage target in every logo. Local review returns to
// this preview's root; this helper is not part of the production design.
if(['127.0.0.1','localhost'].includes(location.hostname)){
  for(const link of document.querySelectorAll('a[data-home]'))link.addEventListener('click',event=>{event.preventDefault();location.href='/';});
}
